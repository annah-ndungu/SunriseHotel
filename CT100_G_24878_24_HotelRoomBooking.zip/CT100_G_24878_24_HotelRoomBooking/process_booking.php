<?php

include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $full_name = $_POST["full_name"];
    $id_passport = $_POST["id_passport"];
    $phone = $_POST["phone"];
    $email = $_POST["email"];
    $check_in = $_POST["check_in"];
    $room_type = $_POST["room_type"];
    $guests = (int)$_POST["guests"];
    $nights = (int)$_POST["nights"];
    $breakfast = $_POST["breakfast"];
    $airport_transfer = $_POST["airport_transfer"];

    /*
     * Room rates
     */
    $roomRates = [
        "Single Room" => 3500,
        "Double Room" => 5000,
        "Family Room" => 7500,
        "Conference Room"=>2000
    ];

    /*
     * Breakfast and airport transfer rates
     */
    $breakfastRate = 700;
    $transferRate = 2000;

    /*
     * Check that the selected room exists
     */
    if (!isset($roomRates[$room_type])) {
        die("Invalid room type selected.");
    }

    /*
     * Check room capacity
     */
    $roomCapacity = [
        "Single Room" => 1,
        "Double Room" => 4,
        "Family Room" => 4
    ];

    if ($guests > $roomCapacity[$room_type]) {
        die("Booking failed. The selected room can accommodate a maximum of " . $roomCapacity[$room_type] . " guest(s).");
    }

    /*
     * Calculate room cost
     */
    $roomCost = $roomRates[$room_type] * $nights;

    /*
     * Calculate breakfast cost
     */
    $breakfastCost = 0;

    if ($breakfast == "Included") {
        $breakfastCost = $breakfastRate * $guests * $nights;
    }

    /*
     * Calculate airport transfer cost
     */
    $transferCost = 0;

    if ($airport_transfer == "Required") {
        $transferCost = $transferRate;
    }

    /*
     * Calculate final total
     */
    $total = $roomCost + $breakfastCost + $transferCost;

    /*
     * Save booking
     */
    $sql = "INSERT INTO bookings 
            (full_name, id_passport, phone, email, check_in, room_type, guests, nights, breakfast, airport_transfer)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "ssssssiiss",
        $full_name,
        $id_passport,
        $phone,
        $email,
        $check_in,
        $room_type,
        $guests,
        $nights,
        $breakfast,
        $airport_transfer
    );

    if ($stmt->execute()) {

        echo "<h1>Booking Successful</h1>";

        echo "<p>Your booking has been saved successfully.</p>";

        echo "<h2>Booking Summary</h2>";

        echo "<p>Room: " . $room_type . "</p>";
        echo "<p>Guests: " . $guests . "</p>";
        echo "<p>Nights: " . $nights . "</p>";
        echo "<p>Breakfast: " . $breakfast . "</p>";
        echo "<p>Airport Transfer: " . $airport_transfer . "</p>";

        echo "<p>Room Cost: KSh " . number_format($roomCost) . "</p>";
        echo "<p>Breakfast Cost: KSh " . number_format($breakfastCost) . "</p>";
        echo "<p>Transfer Cost: KSh " . number_format($transferCost) . "</p>";

        echo "<h2>Total Amount: KSh " . number_format($total) . "</h2>";

    } else {

        echo "<h1>Booking Failed</h1>";
        echo "<p>There was a problem saving your booking.</p>";
    }

    $stmt->close();
    $conn->close();

} else {

    echo "Invalid request.";
}

?>