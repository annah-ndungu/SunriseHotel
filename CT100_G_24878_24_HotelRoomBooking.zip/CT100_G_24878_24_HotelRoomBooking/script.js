const roomRates = {
    "Single Room": 3500,
    "Double Room": 5000,
    "Family Room": 7500,
    "Conference Room":2000
};

const roomCapacity = {
    "Single Room": 1,
    "Double Room": 2,
    "Family Room": 4
};

const breakfastRate = 700;
const transferRate = 2000;


function updateRoomDetails() {
    const roomType = document.getElementById("room_type").value;
    const capacityMessage = document.getElementById("room_capacity");

    if (roomType === "") {
        capacityMessage.innerHTML = "";
        updateBookingSummary();
        return;
    }

    capacityMessage.innerHTML =
        "Maximum guests for this room: " + roomCapacity[roomType];

    updateBookingSummary();
}


function checkGuestCapacity() {
    const roomType = document.getElementById("room_type").value;
    const guests = parseInt(document.getElementById("guests").value) || 0;
    const capacityMessage = document.getElementById("room_capacity");

    if (roomType === "") {
        capacityMessage.innerHTML = "";
        return;
    }

    if (guests > roomCapacity[roomType]) {
        capacityMessage.innerHTML =
            "WARNING: This room allows a maximum of " +
            roomCapacity[roomType] +
            " guest(s).";
    } else {
        capacityMessage.innerHTML =
            "Maximum guests for this room: " +
            roomCapacity[roomType];
    }

    updateBookingSummary();
}


function updateBookingSummary() {
    const roomType = document.getElementById("room_type").value;
    const guests = parseInt(document.getElementById("guests").value) || 0;
    const nights = parseInt(document.getElementById("nights").value) || 0;
    const breakfast = document.getElementById("breakfast").value;
    const airportTransfer =
        document.getElementById("airport_transfer").value;

    const summary = document.getElementById("booking_summary");

    if (roomType === "" || guests === 0 || nights === 0) {
        summary.innerHTML = `
            <h2>Booking Summary</h2>
            <p>Select your booking options to see the summary.</p>
        `;

        document.getElementById("total_amount").value = "";
        return;
    }

    const roomCost = roomRates[roomType] * nights;

    let breakfastCost = 0;

    if (breakfast === "Included") {
        breakfastCost = breakfastRate * guests * nights;
    }

    let transferCost = 0;

    if (airportTransfer === "Required") {
        transferCost = transferRate;
    }

    const total = roomCost + breakfastCost + transferCost;

    summary.innerHTML = `
        <h2>Booking Summary</h2>
        <p><strong>Room:</strong> ${roomType}</p>
        <p><strong>Guests:</strong> ${guests}</p>
        <p><strong>Nights:</strong> ${nights}</p>
        <p><strong>Breakfast:</strong> ${breakfast}</p>
        <p><strong>Airport Transfer:</strong> ${airportTransfer}</p>
        <p><strong>Room Cost:</strong> KSh ${roomCost.toLocaleString()}</p>
        <p><strong>Breakfast Cost:</strong> KSh ${breakfastCost.toLocaleString()}</p>
        <p><strong>Transfer Cost:</strong> KSh ${transferCost.toLocaleString()}</p>
        <p id="total_display">
            Total: KSh ${total.toLocaleString()}
        </p>
    `;

    document.getElementById("total_amount").value = total;
}


function validateBooking() {
    const fullName =
        document.getElementById("full_name").value.trim();

    const idPassport =
        document.getElementById("id_passport").value.trim();

    const phone =
        document.getElementById("phone").value.trim();

    const email =
        document.getElementById("email").value.trim();

    const checkIn =
        document.getElementById("check_in").value;

    const roomType =
        document.getElementById("room_type").value;

    const guests =
        parseInt(document.getElementById("guests").value);

    const nights =
        parseInt(document.getElementById("nights").value);

    const breakfast =
        document.getElementById("breakfast").value;

    const airportTransfer =
        document.getElementById("airport_transfer").value;


    if (fullName === "") {
        alert("Please enter the customer's full name.");
        return false;
    }

    if (idPassport === "") {
        alert("Please enter the National ID or Passport number.");
        return false;
    }

    if (phone === "") {
        alert("Please enter the phone number.");
        return false;
    }

    if (email === "") {
        alert("Please enter the email address.");
        return false;
    }

    if (checkIn === "") {
        alert("Please select the check-in date.");
        return false;
    }

    if (roomType === "") {
        alert("Please select a room type.");
        return false;
    }

    if (guests < 1 || isNaN(guests)) {
        alert("Please enter the number of guests.");
        return false;
    }

    if (guests > roomCapacity[roomType]) {
        alert(
            "This room can accommodate a maximum of " +
            roomCapacity[roomType] +
            " guest(s)."
        );
        return false;
    }

    if (nights < 1 || isNaN(nights)) {
        alert("Please enter the number of nights.");
        return false;
    }

    if (breakfast === "") {
        alert("Please select a breakfast option.");
        return false;
    }

    if (airportTransfer === "") {
        alert("Please select an airport transfer option.");
        return false;
    }

    updateBookingSummary();

    return true;
}